export const HOME_BUCKETS = ['a', 'b', 'c'] as const

export const MARKETING_BUCKETS = ['original', 'b', 'c'] as const
