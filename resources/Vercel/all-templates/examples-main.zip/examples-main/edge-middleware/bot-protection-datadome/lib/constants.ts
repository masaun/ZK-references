export const DATADOME_TAGS = 'https://js.datadome.co/tags.js'

export const DATADOME_JS = 'https://api-js.datadome.co/js/'
