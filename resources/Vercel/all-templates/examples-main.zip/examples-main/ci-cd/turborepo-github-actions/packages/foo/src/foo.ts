export const foo = "bar";
