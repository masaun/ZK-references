---
marketplace: false
---

# Geolocation Country Block

This example has been moved to [`edge-middleware`](/edge-middleware/geolocation-country-block).

