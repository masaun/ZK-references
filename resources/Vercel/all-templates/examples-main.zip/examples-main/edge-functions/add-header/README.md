---
marketplace: false
---

# Add Header Example

This example has been moved to [`edge-middleware`](/edge-middleware/add-header).

