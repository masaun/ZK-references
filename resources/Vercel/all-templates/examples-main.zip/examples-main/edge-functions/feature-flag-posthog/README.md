---
marketplace: false
---

# A/B Testing with PostHog

This example has been moved to [`edge-middleware`](/edge-middleware/feature-flag-posthog).

