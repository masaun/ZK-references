---
marketplace: false
---

# Hostname Rewrites

This example has been moved to [`edge-middleware`](/edge-middleware/hostname-rewrites).
