---
marketplace: false
---

# A/B Testing with Split

This example has been moved to [`edge-middleware`](/edge-middleware/feature-flag-split).
