---
marketplace: false
---

# IP Blocking with DataDome

This example has been moved to [`edge-middleware`](/edge-middleware/ip-blocking-datadome).
