---
marketplace: false
---

# Maintenance Page

This example has been moved to [`edge-middleware`](/edge-middleware/maintenance-page).

