---
marketplace: false
---

# A/B Testing with Google Optimize

This example has been moved to [`edge-middleware`](/edge-middleware/ab-testing-google-optimize).
