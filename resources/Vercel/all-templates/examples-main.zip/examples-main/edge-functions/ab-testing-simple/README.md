---
marketplace: false
---

# A/B Testing Simple

This example has been moved to [`edge-middleware`](/edge-middleware/ab-testing-simple).
