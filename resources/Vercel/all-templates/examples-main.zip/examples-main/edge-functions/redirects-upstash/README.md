---
marketplace: false
---

# Edge Redirects with Upstash

This example has been moved to [`edge-middleware`](/edge-middleware/redirects-upstash).

