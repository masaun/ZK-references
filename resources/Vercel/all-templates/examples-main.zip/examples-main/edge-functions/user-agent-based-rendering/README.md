---
marketplace: false
---

# User-Agent Based Rendering

This example has been moved to [`edge-middleware`](/edge-middleware/user-agent-based-rendering).
