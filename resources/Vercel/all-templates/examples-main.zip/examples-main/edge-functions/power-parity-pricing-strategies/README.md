---
marketplace: false
---

# Power Parity Pricing Strategies

This example has been moved to [`edge-middleware`](/edge-middleware/power-parity-pricing-strategies).
