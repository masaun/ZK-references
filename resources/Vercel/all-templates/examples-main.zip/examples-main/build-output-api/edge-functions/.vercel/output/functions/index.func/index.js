export default function index(request, event) {
  return new Response(`Hello, from the Edge!`)
}
