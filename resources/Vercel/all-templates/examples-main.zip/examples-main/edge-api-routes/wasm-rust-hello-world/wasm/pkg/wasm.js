import * as wasm from "./wasm_bg.wasm";
export * from "./wasm_bg.js";