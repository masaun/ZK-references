/* tslint:disable */
/* eslint-disable */
/**
 * @returns {string}
 */
export function greet(): string
